# cloud/api/assistant/planner.py
from __future__ import annotations
from typing import Any, Dict, List, Tuple, Optional

from .agents import PlannerAgent, ToolExecutorAgent, ChatAgent, PlannerDecision


planner_agent = PlannerAgent()
tool_executor = ToolExecutorAgent()
chat_agent = ChatAgent()


async def run_tool_flow(
    message: str,
    device: Dict[str, Any],
    history: List[Dict[str, Any]],
) -> Tuple[str, List[Dict[str, Any]]]:
    """
    This will be called when the route decides we should do a tools/mixed flow.

    Returns:
    - reply_text
    - tools_used (list of dicts with metadata)
    """
    decision: PlannerDecision = await planner_agent.plan(
        message=message,
        history=history,
        mode_override="tools",
        device=device,
    )

    reply, tools_meta = await tool_executor.run(
        message=message,
        decision=decision,
        history=history,
        device=device,
    )

    return reply, tools_meta


async def run_mcp_flow(
    message: str,
    device: Dict[str, Any],
    history: List[Dict[str, Any]],
) -> Tuple[str, List[Dict[str, Any]]]:
    """
    Placeholder for MCP toolchains.
    For now, we just reuse tool flow behaviour.
    """
    return await run_tool_flow(message=message, device=device, history=history)
