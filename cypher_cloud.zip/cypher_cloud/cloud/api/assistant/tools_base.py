# cloud/api/assistant/tools_base.py
from __future__ import annotations
from typing import Any, Dict, Protocol, Callable, Awaitable, Optional
import inspect
import asyncio


class ToolContext(Dict[str, Any]):
    """
    Simple context object passed to tools.
    You can later extend this with:
    - device info
    - auth info
    - tracing / logging
    """


class Tool(Protocol):
    name: str
    description: str

    async def __call__(self, *, args: Dict[str, Any], ctx: ToolContext) -> Any:
        ...


class RegisteredTool:
    """
    Concrete wrapper around a callable that acts as a tool.
    """

    def __init__(
        self,
        name: str,
        description: str,
        func: Callable[..., Any],
    ) -> None:
        self.name = name
        self.description = description
        self.func = func

    async def __call__(self, *, args: Dict[str, Any], ctx: ToolContext) -> Any:
        # Call the underlying function; support both sync and async.
        try:
            if inspect.iscoroutinefunction(self.func):
                return await self.func(**args, ctx=ctx)
            else:
                # Run sync function in a thread pool to avoid blocking
                loop = asyncio.get_running_loop()
                return await loop.run_in_executor(
                    None, lambda: self.func(**args, ctx=ctx)
                )
        except TypeError:
            # Fallback if tool doesn't accept ctx
            if inspect.iscoroutinefunction(self.func):
                return await self.func(**args)
            else:
                loop = asyncio.get_running_loop()
                return await loop.run_in_executor(
                    None, lambda: self.func(**args)
                )
