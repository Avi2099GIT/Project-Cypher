# cloud/api/assistant/tools_registry.py
from __future__ import annotations
from typing import Dict, Any, List, Optional, Tuple

from .tools_base import RegisteredTool, ToolContext


class ToolRegistry:
    """
    In-memory registry of tools.

    Later:
    - You can persist this
    - Or load from plugin descriptors, MCP, etc.
    """

    def __init__(self) -> None:
        self._tools: Dict[str, RegisteredTool] = {}

    def register(self, tool: RegisteredTool) -> None:
        if tool.name in self._tools:
            raise ValueError(f"Tool with name '{tool.name}' already registered")
        self._tools[tool.name] = tool

    def get(self, name: str) -> Optional[RegisteredTool]:
        return self._tools.get(name)

    def list(self) -> List[RegisteredTool]:
        return list(self._tools.values())

    async def call(
        self,
        name: str,
        args: Dict[str, Any],
        ctx: Optional[ToolContext] = None,
    ) -> Tuple[Any, Dict[str, Any]]:
        ctx = ctx or ToolContext()
        tool = self.get(name)
        if not tool:
            raise ValueError(f"Unknown tool: {name}")

        result = await tool(args=args, ctx=ctx)
        meta = {
            "tool": name,
            "ok": True,
        }
        return result, meta


# Global singleton registry for now
tool_registry = ToolRegistry()


def register_builtin_tools() -> None:
    """
    Register a few simple built-in tools so the planner has something to call.
    You can expand this later with:
    - weather
    - browsing
    - file ops
    - reminders
    etc.
    """

    async def echo_tool(text: str, ctx: ToolContext) -> str:
        return f"[echo] {text}"

    tool_registry.register(
        RegisteredTool(
            name="echo",
            description="Echoes back the provided text. Useful for testing tool routing.",
            func=echo_tool,
        )
    )

    async def summarize_tool(text: str, ctx: ToolContext) -> str:
        # Placeholder summarizer – later replace with real LLM call or
        # call into your existing brain.
        if len(text) <= 200:
            return f"[summary] {text}"
        return f"[summary] {text[:200]}..."

    tool_registry.register(
        RegisteredTool(
            name="summarize",
            description="Summarizes a piece of text (placeholder implementation).",
            func=summarize_tool,
        )
    )
