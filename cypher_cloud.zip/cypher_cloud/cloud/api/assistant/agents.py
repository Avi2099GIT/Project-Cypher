# cloud/api/assistant/agents.py
from __future__ import annotations
from typing import Any, Dict, List, Literal, Optional, Tuple

from .tools_registry import tool_registry, register_builtin_tools
from .tools_base import ToolContext


PlannerDecisionMode = Literal["chat", "tools", "mixed", "mcp"]


class PlannerDecision(Dict[str, Any]):
    """
    Simple dict-based object, but we access keys as attributes.
    """

    def __getattr__(self, item: str) -> Any:
        try:
            return self[item]
        except KeyError:
            raise AttributeError(item)


class PlannerAgent:
    """
    Decides whether to:
    - answer with pure chat
    - call tools
    - do mixed mode
    - or delegate to MCP

    For now, logic is simple and deterministic; later we can route via LLM.
    """

    def __init__(self) -> None:
        register_builtin_tools()

    async def plan(
        self,
        message: str,
        history: List[Dict[str, Any]],
        mode_override: Optional[str] = None,
        device: Optional[Dict[str, Any]] = None,
    ) -> PlannerDecision:
        # If user explicitly sets mode, respect it blindly
        if mode_override and mode_override != "auto":
            return PlannerDecision(mode=mode_override)

        # Naive heuristic for now – later this becomes an LLM planning prompt
        lower = message.lower()

        if "tool:" in lower or "echo:" in lower:
            return PlannerDecision(
                mode="tools",
                tools=[{"name": "echo"}],
            )

        if "summarize" in lower:
            return PlannerDecision(
                mode="tools",
                tools=[{"name": "summarize"}],
            )

        # Default: chat
        return PlannerDecision(mode="chat")


class ToolExecutorAgent:
    """
    Executes tools according to planner output.
    """

    async def run(
        self,
        message: str,
        decision: PlannerDecision,
        history: List[Dict[str, Any]],
        device: Optional[Dict[str, Any]] = None,
    ) -> Tuple[str, List[Dict[str, Any]]]:
        ctx = ToolContext(device=device or {}, history=history)
        tools_meta: List[Dict[str, Any]] = []

        tools = decision.get("tools") or []
        if not tools:
            # Fallback: call echo
            tools = [{"name": "echo", "args": {"text": message}}]

        tool_outputs = []
        for t in tools:
            name = t["name"]
            args = t.get("args") or {}

            # Default arg mapping: send whole message as "text"
            if not args:
                args = {"text": message}

            result, meta = await tool_registry.call(name, args, ctx)
            tools_meta.append(meta)
            tool_outputs.append(f"[{name} result]: {result}")

        # Very naive aggregation; later this will be an LLM that reads tool outputs
        final_reply = "\n".join(tool_outputs)
        return final_reply, tools_meta


class ChatAgent:
    """
    Simple chat agent; for now just echoes.
    Later: use OpenAI / whatever LLM you're already using in cloud.
    """

    async def run(
        self,
        message: str,
        history: List[Dict[str, Any]],
        device: Optional[Dict[str, Any]] = None,
    ) -> str:
        # Placeholder: keep behaviour close to your current brain:
        return "Hi there! How can I help you today?"
