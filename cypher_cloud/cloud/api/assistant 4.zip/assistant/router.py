from __future__ import annotations

from typing import Dict, Any, List
from fastapi import APIRouter
from pydantic import BaseModel, Field

from .agents_dir.brain import CypherBrain
from .memory import memory_service

router = APIRouter(prefix="/v1/assistant", tags=["Assistant"])

# Create one shared Cypher brain instance
brain = CypherBrain()


# -------------------------------------------------------------------
# Request / Response models
# -------------------------------------------------------------------


class AssistantQuery(BaseModel):
    message: str


class AssistantResponse(BaseModel):
    reply_text: str
    tools_used: List[Dict[str, Any]] = Field(default_factory=list)
    memory_used: Dict[str, Any] = Field(default_factory=dict)


# -------------------------------------------------------------------
# MAIN ENDPOINT (MULTI-AGENT PIPELINE)
# -------------------------------------------------------------------


@router.post("/query", response_model=AssistantResponse)
async def assistant_query(payload: AssistantQuery):

    # Identify device (placeholder until auth/device registry is added)
    device: Dict[str, Any] = {"device_id": "local-dev"}

    # Retrieve episodic memory (short-term context)
    history: List[Dict[str, Any]] = memory_service.get_recent_episodes(
        device=device,
        limit=10,
    )

    if not history:
        history = []

    # Shared context for Cypher brain
    ctx: Dict[str, Any] = {
        "device": device,
        "history": history,
        "message": payload.message,
    }

    # --------------------------------------------------------
    # Run Cypher Core Brain
    # --------------------------------------------------------
    reply_text, tools_used = await brain.process(payload.message, ctx)

    # --------------------------------------------------------
    # Store memory episodes (Memory V2)
    # --------------------------------------------------------
    try:
        memory_service.store_episode(
            device=device,
            role="user",
            content=payload.message,
            meta={"source": "api"},
        )

        memory_service.store_episode(
            device=device,
            role="assistant",
            content=reply_text,
            meta={"source": "api"},
        )

    except Exception:
        # Memory must never crash the API
        import logging
        logging.exception("Failed to store memory episode")

    # --------------------------------------------------------
    # Snapshot memory (for UI / debug tools)
    # --------------------------------------------------------
    try:
        memory_view = {
            "recent_episodes": memory_service.get_recent_episodes(device, limit=10)
        }
    except Exception:
        memory_view = {}

    return AssistantResponse(
        reply_text=str(reply_text),
        tools_used=tools_used,
        memory_used=memory_view,
    )
