# cloud/api/assistant/orchestrator/graph.py
from __future__ import annotations

from typing import Dict, List, Optional, Set
import asyncio
import logging
import time
import traceback

from .node import GraphNode, NodeStatus
from .state import ExecutionContext
from .tracer import GraphTracer

logger = logging.getLogger(__name__)


class AgentGraph:
    """
    Orchestration graph for Cypher.

    - Nodes can depend on each other.
    - Nodes whose hard deps succeeded can run in parallel.
    - If a required dep fails, dependents are marked SKIPPED.
    """

    def __init__(self, name: str = "default") -> None:
        self.name = name
        self._nodes: Dict[str, GraphNode] = {}

    # ------------- node registration -------------

    def add_node(self, node: GraphNode) -> None:
        if node.name in self._nodes:
            raise ValueError(f"Node with name {node.name!r} already exists.")
        self._nodes[node.name] = node

    def get_node(self, name: str) -> GraphNode:
        return self._nodes[name]

    @property
    def nodes(self) -> Dict[str, GraphNode]:
        return dict(self._nodes)

    # ------------- execution -------------

    async def run(
        self,
        ctx: ExecutionContext,
        tracer: Optional[GraphTracer] = None,
    ) -> ExecutionContext:
        """
        Execute the graph for a single query.

        Algorithm:
          - Find nodes whose hard deps are SUCCESS (or have no deps).
          - Run them in layers; within each layer, run parallel nodes with asyncio.gather.
          - If a hard dependency FAILED, mark dependent as SKIPPED.
          - If we get stuck with pending nodes and no runnable nodes → graph misconfigured (cycle).
        """
        tracer = tracer or GraphTracer()
        logger.info("Starting graph run name=%s trace_id=%s", self.name, ctx.trace_id)

        # Initialize all node statuses as PENDING
        for name in self._nodes.keys():
            if ctx.get_result(name) is None:
                ctx.set_result(name, status=NodeStatus.PENDING)

        remaining: Set[str] = set(self._nodes.keys())

        while remaining:
            runnable = self._find_runnable(remaining, ctx)
            if not runnable:
                # Either everything is done or we have unresolved deps / cycles.
                # Mark anything still pending as FAILED with an appropriate msg.
                self._mark_unreachable(remaining, ctx, tracer)
                break

            layer = [self._nodes[name] for name in runnable]
            await self._run_layer(layer, remaining, ctx, tracer)

        ctx.log_summary()
        return ctx

    # ------------- helpers -------------

    def _find_runnable(
        self,
        remaining: Set[str],
        ctx: ExecutionContext,
    ) -> List[str]:
        """
        Find nodes whose:
          - status is PENDING
          - all hard deps (requires) are SUCCESS
          - none of the hard deps are FAILED/SKIPPED
        """
        runnable: List[str] = []

        for name in list(remaining):
            res = ctx.get_result(name)
            if not res or res.status != NodeStatus.PENDING:
                continue

            node = self._nodes[name]
            hard_deps = node.requires

            hard_statuses = [
                ctx.get_result(dep).status if ctx.get_result(dep) else NodeStatus.PENDING
                for dep in hard_deps
            ]

            if any(s in (NodeStatus.FAILED, NodeStatus.SKIPPED) for s in hard_statuses):
                # A hard dependency failed → this node is skipped
                tracer_msg = f"Hard dependency failed for {name}, marking SKIPPED."
                logger.warning(tracer_msg)
                ctx.set_result(name, status=NodeStatus.SKIPPED, error=tracer_msg)
                continue

            # All hard deps must be SUCCESS to run
            if all(s == NodeStatus.SUCCESS for s in hard_statuses):
                runnable.append(name)

        return runnable

    async def _run_layer(
        self,
        layer: List[GraphNode],
        remaining: Set[str],
        ctx: ExecutionContext,
        tracer: GraphTracer,
    ) -> None:
        """
        Run one layer of nodes. Nodes with allow_parallel=True are run together.
        Those with allow_parallel=False are run one by one (in order).
        """
        parallel_nodes = [n for n in layer if n.allow_parallel]
        sequential_nodes = [n for n in layer if not n.allow_parallel]

        # Run parallel group first
        if parallel_nodes:
            await self._run_parallel_group(parallel_nodes, remaining, ctx, tracer)

        # Then run sequential nodes in order
        for node in sequential_nodes:
            await self._run_single(node, remaining, ctx, tracer)

    async def _run_parallel_group(
        self,
        nodes: List[GraphNode],
        remaining: Set[str],
        ctx: ExecutionContext,
        tracer: GraphTracer,
    ) -> None:
        tasks = [
            self._run_single(node, remaining, ctx, tracer, remove_from_remaining=False)
            for node in nodes
        ]
        await asyncio.gather(*tasks)
        for node in nodes:
            remaining.discard(node.name)

    async def _run_single(
        self,
        node: GraphNode,
        remaining: Set[str],
        ctx: ExecutionContext,
        tracer: GraphTracer,
        remove_from_remaining: bool = True,
    ) -> None:
        name = node.name
        logger.debug("Running node=%s trace_id=%s", name, ctx.trace_id)

        res = ctx.get_result(name)
        if not res:
            res = ctx.set_result(name, status=NodeStatus.PENDING)

        # If node already terminal, skip
        if res.status in (NodeStatus.SUCCESS, NodeStatus.FAILED, NodeStatus.SKIPPED):
            if remove_from_remaining:
                remaining.discard(name)
            return

        started = time.time()
        ctx.set_result(name, status=NodeStatus.RUNNING, started_at=started)
        tracer.record(node=name, status=NodeStatus.RUNNING, message="start")

        try:
            output = await node.run(ctx)
            finished = time.time()
            ctx.set_result(
                name,
                status=NodeStatus.SUCCESS,
                output=output,
                started_at=started,
                finished_at=finished,
            )
            tracer.record(
                node=name,
                status=NodeStatus.SUCCESS,
                message="success",
                extra={"duration_ms": (finished - started) * 1000.0},
            )
        except Exception as e:
            finished = time.time()
            err_text = "".join(traceback.format_exception(type(e), e, e.__traceback__))
            logger.exception("Node %s failed: %s", name, e)
            ctx.set_result(
                name,
                status=NodeStatus.FAILED,
                error=str(e),
                started_at=started,
                finished_at=finished,
            )
            tracer.record(
                node=name,
                status=NodeStatus.FAILED,
                message=str(e),
                extra={"traceback": err_text},
            )

        if remove_from_remaining:
            remaining.discard(name)

    def _mark_unreachable(
        self,
        remaining: Set[str],
        ctx: ExecutionContext,
        tracer: GraphTracer,
    ) -> None:
        """
        Called when there are still remaining nodes but none runnable:
        implies a configuration error (dependency cycle or missing deps).
        """
        if not remaining:
            return

        msg = (
            f"Unreachable nodes in graph={self.name}: {sorted(remaining)}. "
            "Likely due to a dependency cycle or missing required nodes."
        )
        logger.error(msg)

        for name in list(remaining):
            res = ctx.get_result(name)
            if res and res.status not in (NodeStatus.PENDING, NodeStatus.RUNNING):
                continue
            ctx.set_result(name, status=NodeStatus.FAILED, error=msg)
            tracer.record(
                node=name,
                status=NodeStatus.FAILED,
                message="unreachable due to graph config error",
            )
