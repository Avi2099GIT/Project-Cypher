# cloud/api/assistant/orchestrator/tracer.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional
import time
import logging

from .node import NodeStatus

logger = logging.getLogger(__name__)


@dataclass
class GraphEvent:
    timestamp: float
    node: str
    status: NodeStatus
    message: str
    extra: Dict[str, Any]


class GraphTracer:
    """
    Simple in-memory tracer for graph runs.
    Can later be extended to export traces to logs, files, dashboards, etc.
    """

    def __init__(self) -> None:
        self._events: List[GraphEvent] = []

    def record(
        self,
        *,
        node: str,
        status: NodeStatus,
        message: str = "",
        extra: Optional[Dict[str, Any]] = None,
    ) -> None:
        evt = GraphEvent(
            timestamp=time.time(),
            node=node,
            status=status,
            message=message,
            extra=extra or {},
        )
        self._events.append(evt)
        logger.debug(
            "Graph event node=%s status=%s msg=%s extra=%s",
            node,
            status.name,
            message,
            extra or {},
        )

    @property
    def events(self) -> List[GraphEvent]:
        return list(self._events)

    def to_dict(self) -> List[Dict[str, Any]]:
        return [
            {
                "timestamp": e.timestamp,
                "node": e.node,
                "status": e.status.name,
                "message": e.message,
                "extra": e.extra,
            }
            for e in self._events
        ]
