# cloud/api/assistant/orchestrator/executor.py
from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple
import logging

from .graph import AgentGraph
from .state import ExecutionContext
from .tracer import GraphTracer

logger = logging.getLogger(__name__)


class GraphExecutor:
    """
    High-level entry point for running an AgentGraph.

    This does NOT hard-code any specific agents.
    In later parts of Phase 4, we will:
      - Build a default Cypher graph (intent → entity → safety → planner → tools → verifier → chat)
      - Wire agents_dir.* into concrete GraphNodes
      - Use this executor from brain/router.
    """

    def __init__(self, graph: AgentGraph) -> None:
        self.graph = graph

    async def run_query(
        self,
        *,
        message: str,
        history: List[Dict[str, Any]],
        device: Optional[Dict[str, Any]] = None,
        extras: Optional[Dict[str, Any]] = None,
    ) -> Tuple[ExecutionContext, GraphTracer]:
        device = device or {}
        extras = extras or {}
        ctx = ExecutionContext(
            message=message,
            history=history,
            device=device,
            extras=extras,
        )
        tracer = GraphTracer()

        logger.info(
            "GraphExecutor starting query trace_id=%s graph=%s device=%s",
            ctx.trace_id,
            self.graph.name,
            device.get("device_id") or device.get("id") or "unknown-device",
        )

        ctx = await self.graph.run(ctx, tracer=tracer)

        logger.info(
            "GraphExecutor finished query trace_id=%s graph=%s",
            ctx.trace_id,
            self.graph.name,
        )

        return ctx, tracer
