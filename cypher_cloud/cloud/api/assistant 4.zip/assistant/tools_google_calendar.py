from __future__ import annotations

from typing import Dict, Any, Tuple
from datetime import datetime, timedelta, timezone, time
import re

from googleapiclient.discovery import build
from dateutil import parser as date_parser

from cloud.api.assistant.google_auth import get_google_creds


def _get_calendar_service():
    """Build a Google Calendar API service using stored / refreshed user creds."""
    creds = get_google_creds()
    return build("calendar", "v3", credentials=creds)


# ---------------------------------------------------
# TIME PARSING HELPERS
# ---------------------------------------------------

_MONTH_PATTERN = re.compile(
    r"\b("
    r"jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec|"
    r"january|february|march|april|june|july|august|september|october|november|december"
    r")\b",
    re.IGNORECASE,
)


def _has_explicit_date(text: str) -> bool:
    """Return True if the text obviously contains a calendar date."""
    t = text.lower()
    if re.search(r"\d{4}-\d{2}-\d{2}", t):
        return True
    if re.search(r"\d{1,2}/\d{1,2}/\d{2,4}", t):
        return True
    if _MONTH_PATTERN.search(t):
        return True
    if re.search(r"\d{1,2}(st|nd|rd|th)\b", t):
        return True
    return False


def _parse_time_only(text: str, base_date: datetime.date) -> datetime:
    """
    Parse only the time-of-day from text and combine with base_date.

    SAFE GUARANTEE:
      - Never inherits current minutes when user says '9pm'.
      - If parsing fails, defaults to 09:00 on base_date.
    """
    text = (text or "").strip()
    default_time = time(hour=9, minute=0)

    if not text:
        t = default_time
    else:
        try:
            dt = date_parser.parse(text, fuzzy=True, default=datetime(2000, 1, 1))
            t = dt.time()
        except Exception:
            # Fallback: 09:00
            t = default_time

    lower = text.lower()
    if (("am" in lower or "pm" in lower) and ":" not in lower):
        # "9pm" → 21:00 exactly, not 21:current-minute
        t = t.replace(minute=0, second=0, microsecond=0)

    return datetime.combine(base_date, t)


def _parse_human_time(when_str: str) -> str | None:
    """
    STRICT datetime compositor.

    Rules:
    - If explicit calendar date present → DATE derived ONLY from text.
    - If relative word present → DATE manually derived.
    - If only time present → assume today.
    - Time NEVER inherits current minute/second.
    - NO silent date injection.

    Returns ISO UTC timestamp.
    """

    when_str = (when_str or "").strip()
    if not when_str:
        return None

    lower = when_str.lower()
    now = datetime.now()
    local_tz = now.astimezone().tzinfo or timezone.utc

    # --------------------------------
    # EXPLICIT DATE — STRICT EXTRACTION
    # --------------------------------
    if _has_explicit_date(when_str):

        # 1) Extract DATE only
        try:
            date_part = date_parser.parse(
                when_str,
                fuzzy=True,
                default=datetime(1990, 1, 1)
            ).date()
        except Exception:
            return None

        # 2) Extract TIME ONLY (SAFE)
        time_part = None
        try:
            t = date_parser.parse(
                when_str,
                fuzzy=True,
                default=datetime(2000, 1, 1)
            )
            time_part = t.time()
        except Exception:
            pass

        if time_part is None:
            time_part = time(hour=9, minute=0)

        # 3) Compose explicitly
        dt_local = datetime.combine(date_part, time_part)

        # ✅ wipe noise fields
        dt_local = dt_local.replace(second=0, microsecond=0)

        # timezone
        dt_local = dt_local.replace(tzinfo=local_tz)

        return dt_local.astimezone(timezone.utc).isoformat()

    # --------------------------------
    # RELATIVE DATE HANDLING
    # --------------------------------
    base_date = now.date()

    if "tomorrow" in lower:
        base_date += timedelta(days=1)

    # Remove relative words
    time_text = re.sub(
        r"\b(today|tomorrow|tonight)\b",
        "",
        lower
    ).strip()

    # --------------------------------
    # TIME ONLY PARSE
    # --------------------------------
    try:
        t = date_parser.parse(
            time_text if time_text else "9am",
            fuzzy=True,
            default=datetime(2000, 1, 1)
        ).time()
    except Exception:
        return None

    # ✅ Never inherit minute drift
    if ("am" in lower or "pm" in lower) and ":" not in lower:
        t = t.replace(minute=0, second=0, microsecond=0)

    # Compose final
    dt_local = datetime.combine(base_date, t)
    dt_local = dt_local.replace(tzinfo=local_tz)

    return dt_local.astimezone(timezone.utc).isoformat()



# ---------------------------------------------------
# LIST RANGE PARSER
# ---------------------------------------------------

def _parse_human_range(text: str) -> Tuple[datetime, datetime]:
    """
    Parse human phrases into a date range for LIST / SHOW.

    Supported:
      - "today"            → [today, today+1d)
      - "tomorrow"         → [tomorrow, tomorrow+1d)
      - "this week"        → [today, today+7d)
      - explicit date      → that calendar day
      - anything else      → next 7 days

    Always returns UTC datetimes.
    """
    text = (text or "").lower()
    now = datetime.now(timezone.utc)

    start = now.replace(hour=0, minute=0, second=0, microsecond=0)

    # Relative phrases
    if "today" in text:
        return start, start + timedelta(days=1)

    if "tomorrow" in text:
        s = start + timedelta(days=1)
        return s, s + timedelta(days=1)

    if "this week" in text:
        return start, start + timedelta(days=7)

    # Explicit date, e.g. "on Dec 3"
    try:
        dt = date_parser.parse(text, fuzzy=True)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        s = dt.replace(hour=0, minute=0, second=0, microsecond=0)
        return s, s + timedelta(days=1)
    except Exception:
        # FINAL fallback → next 7 days
        return start, start + timedelta(days=7)


# ---------------------------------------------------
# MAIN TOOL
# ---------------------------------------------------

async def calendar_google_tool(args: Dict[str, Any], ctx: dict) -> Dict[str, Any]:
    """
    Google Calendar integration.

    Actions:
      - list / show / upcoming   → date-aware range
      - create / add / schedule  → create 30-minute event
      - delete / remove / cancel → delete nearest matching
      - update / reschedule      → reschedule event
    """
    service = _get_calendar_service()

    raw_msg = str(ctx.get("message") or "")
    lower_msg = raw_msg.lower()
    action = (args.get("action") or "").lower().strip()

    # Basic inference when action isn't explicitly provided
    if not action:
        if "show" in lower_msg or "upcoming" in lower_msg or "calendar" in lower_msg:
            action = "list"
        else:
            action = "create"

    # ------------------- LIST EVENTS -------------------
    if action in ("list", "show", "upcoming"):
        # ✅ ALWAYS use safe range parser here — never raw dateutil on full phrase
        start_dt, end_dt = _parse_human_range(raw_msg)

        results = service.events().list(
            calendarId="primary",
            timeMin=start_dt.isoformat(),
            timeMax=end_dt.isoformat(),
            maxResults=20,
            singleEvents=True,
            orderBy="startTime",
        ).execute()

        events = results.get("items", [])

        parsed = []
        for ev in events:
            parsed.append(
                {
                    "id": ev.get("id"),
                    "title": ev.get("summary") or "Untitled Event",
                    "start": ev.get("start", {}).get("dateTime")
                    or ev.get("start", {}).get("date"),
                    "end": ev.get("end", {}).get("dateTime")
                    or ev.get("end", {}).get("date"),
                    "htmlLink": ev.get("htmlLink"),
                }
            )

        return {
            "status": "ok",
            "mode": "list",
            "count": len(parsed),
            "range": {
                "start": start_dt.isoformat(),
                "end": end_dt.isoformat(),
            },
            "events": parsed,
        }

    # ------------------- CREATE EVENT -------------------
    if action in ("create", "add", "schedule"):
        title = (args.get("title") or "").strip() or "Cypher Event"

        when_iso = args.get("when_iso")
        if not when_iso:
            when_iso = _parse_human_time(raw_msg)

        if not when_iso:
            return {
                "status": "error",
                "mode": "create",
                "message": (
                    "I couldn't understand the event time. "
                    "Try something like 'tomorrow at 6 PM' or "
                    "'on 3rd December 2025 at 9 PM'."
                ),
            }

        dt = datetime.fromisoformat(when_iso)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)

        end_dt = dt + timedelta(minutes=30)

        event_body = {
            "summary": title,
            "start": {"dateTime": dt.isoformat()},
            "end": {"dateTime": end_dt.isoformat()},
        }

        created = service.events().insert(
            calendarId="primary", body=event_body
        ).execute()

        return {
            "status": "ok",
            "mode": "create",
            "id": created.get("id"),
            "title": created.get("summary"),
            "start": created.get("start", {}).get("dateTime")
            or created.get("start", {}).get("date"),
            "end": created.get("end", {}).get("dateTime")
            or created.get("end", {}).get("date"),
            "htmlLink": created.get("htmlLink"),
        }

    # ------------------- DELETE EVENT -------------------
    if action in ("delete", "remove", "cancel"):
        query = (args.get("query") or "").lower()

        now = datetime.now(timezone.utc).isoformat()

        events = service.events().list(
            calendarId="primary",
            timeMin=now,
            maxResults=50,
            singleEvents=True,
            orderBy="startTime",
        ).execute().get("items", [])

        if not events:
            return {"status": "error", "message": "No upcoming events found."}

        matched = []
        for ev in events:
            title = (ev.get("summary") or "").lower()
            start = ev.get("start", {}).get("dateTime", "") or ""
            if query and (query in title or query in start.lower()):
                matched.append(ev)

        target = matched[0] if matched else events[0]

        service.events().delete(
            calendarId="primary", eventId=target["id"]
        ).execute()

        return {
            "status": "ok",
            "mode": "delete",
            "deleted": {
                "title": target.get("summary"),
                "start": target.get("start"),
            },
        }

    # ------------------- RESCHEDULE EVENT -------------------
    if action in ("update", "reschedule", "move"):
        raw = raw_msg
        new_time_phrase = (args.get("new_time") or "").strip()

        if not new_time_phrase:
            parts = re.split(r"\bto\b", raw, maxsplit=1, flags=re.IGNORECASE)
            if len(parts) == 2:
                new_time_phrase = parts[1].strip()
            else:
                new_time_phrase = raw

        new_time_iso = _parse_human_time(new_time_phrase)
        if not new_time_iso:
            return {
                "status": "error",
                "message": "I couldn't understand the new time for reschedule.",
            }

        new_dt = datetime.fromisoformat(new_time_iso)
        if new_dt.tzinfo is None:
            new_dt = new_dt.replace(tzinfo=timezone.utc)

        new_end = new_dt + timedelta(minutes=30)

        now = datetime.now(timezone.utc).isoformat()
        events = service.events().list(
            calendarId="primary",
            timeMin=now,
            maxResults=30,
            singleEvents=True,
            orderBy="startTime",
        ).execute().get("items", [])

        if not events:
            return {
                "status": "error",
                "message": "No upcoming event found to reschedule.",
            }

        target = events[0]

        target["start"] = {"dateTime": new_dt.isoformat()}
        target["end"] = {"dateTime": new_end.isoformat()}

        updated = service.events().update(
            calendarId="primary", eventId=target["id"], body=target
        ).execute()

        return {
            "status": "ok",
            "mode": "update",
            "rescheduled": {
                "title": updated.get("summary"),
                "new_time": updated.get("start", {}).get("dateTime")
                or updated.get("start", {}).get("date"),
                "htmlLink": updated.get("htmlLink"),
            },
        }

    # ------------------- UNKNOWN ACTION -------------------
    return {
        "status": "error",
        "message": f"Unknown calendar action: {action}",
    }
