from __future__ import annotations

import os
import pickle
from typing import Optional

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow


# -----------------------------------------------------
# Absolute path resolution to /cypher_cloud/keys
# -----------------------------------------------------

BASE_DIR = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "../../../")
)

KEYS_PATH = os.path.join(BASE_DIR, "keys")

CREDS_FILE = os.path.join(KEYS_PATH, "google_credentials.json")
TOKEN_FILE = os.path.join(KEYS_PATH, "google_token.pickle")


SCOPES = [
    "https://www.googleapis.com/auth/calendar",
    "https://www.googleapis.com/auth/tasks",
]


# -----------------------------------------------------
# Main credential loader
# -----------------------------------------------------

def get_google_creds() -> Credentials:
    creds: Optional[Credentials] = None

    # ---------- sanity check ----------
    if not os.path.exists(CREDS_FILE):
        raise FileNotFoundError(
            f"Google credentials file not found at:\n{CREDS_FILE}\n"
            f"Make sure google_credentials.json exists in /cypher_cloud/keys/"
        )

    # ---------- load token ----------
    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE, "rb") as f:
            creds = pickle.load(f)

    # ---------- refresh or login ----------
    if not creds or not creds.valid:

        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())

        else:
            flow = InstalledAppFlow.from_client_secrets_file(CREDS_FILE, SCOPES)
            creds = flow.run_local_server(port=0)

        # ---------- save token ----------
        with open(TOKEN_FILE, "wb") as f:
            pickle.dump(creds, f)

    return creds
