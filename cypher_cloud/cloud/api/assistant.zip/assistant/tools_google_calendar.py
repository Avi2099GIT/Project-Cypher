from __future__ import annotations
from typing import Dict, Any, List
from datetime import datetime, timedelta, timezone
from googleapiclient.discovery import build
from cloud.api.assistant.google_auth import get_google_creds

import dateparser


# ---------------------------------------------------
# Setup
# ---------------------------------------------------

def _get_calendar_service():
    creds = get_google_creds()
    return build("calendar", "v3", credentials=creds)


# ---------------------------------------------------
# Normalized Time Parser
# ---------------------------------------------------

def _parse_time(raw: str | None) -> datetime | None:
    if not raw:
        return None

    dt = dateparser.parse(
        raw,
        settings={
            "PREFER_DATES_FROM": "future",
            "RETURN_AS_TIMEZONE_AWARE": True,
        },
    )

    if not dt:
        return None

    # Ensure timezone
    if not dt.tzinfo:
        dt = dt.replace(tzinfo=timezone.utc)

    return dt


# ---------------------------------------------------
# Google Calendar Tool
# ---------------------------------------------------

async def calendar_google_tool(args: Dict[str, Any], ctx: dict) -> Dict[str, Any]:
    service = _get_calendar_service()

    action = args.get("action", "create")

    title = (
        args.get("title")
        or args.get("summary")
        or "Cypher Event"
    )

    raw_when = (
        args.get("when")
        or args.get("time")
        or args.get("datetime")
        or args.get("time_hint")
        or ctx.get("message")
    )

    # ---------------------------------------------------
    # LIST EVENTS
    # ---------------------------------------------------

    if action == "list":
        now = datetime.utcnow().isoformat() + "Z"
        events = service.events().list(
            calendarId="primary",
            timeMin=now,
            maxResults=10,
            singleEvents=True,
            orderBy="startTime",
        ).execute()

        return {
            "status": "ok",
            "events": [
                {
                    "id": ev["id"],
                    "title": ev.get("summary"),
                    "start": ev["start"].get("dateTime") or ev["start"].get("date"),
                    "link": ev.get("htmlLink"),
                }
                for ev in events.get("items", [])
            ],
        }

    # ---------------------------------------------------
    # DELETE EVENT
    # ---------------------------------------------------

    if action == "delete":
        event_id = args.get("id") or args.get("event_id")

        if not event_id:
            return {"status": "error", "message": "Missing event id."}

        service.events().delete(
            calendarId="primary",
            eventId=event_id
        ).execute()

        return {"status": "ok", "deleted": event_id}

    # ---------------------------------------------------
    # CREATE EVENT
    # ---------------------------------------------------

    if action == "create":

        start_dt = _parse_time(raw_when)

        if not start_dt:
            return {
                "status": "error",
                "message": f"Could not parse time from: {raw_when}",
            }

        end_dt = start_dt + timedelta(hours=1)

        event = {
            "summary": title,
            "start": {"dateTime": start_dt.isoformat()},
            "end": {"dateTime": end_dt.isoformat()},
        }

        created = service.events().insert(
            calendarId="primary",
            body=event,
        ).execute()

        return {
            "status": "ok",
            "event_id": created["id"],
            "title": created.get("summary"),
            "start": created["start"]["dateTime"],
            "link": created.get("htmlLink"),
        }

    return {
        "status": "error",
        "message": f"Unknown calendar action: {action}",
    }
