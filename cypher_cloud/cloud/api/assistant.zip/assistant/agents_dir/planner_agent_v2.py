from __future__ import annotations

from typing import List, Dict, Any, Set
from cloud.api.assistant.agents_dir.plan_model import (
    ExecutionPlan,
    PlanStep,
    PlanRisk,
)


class PlannerV2:
    """
    Phase-4 planner with:
      - multi-candidate plan generation
      - context-aware scoring
      - failure-aware tool biasing

    It does NOT call tools itself; it only decides *what* should be run.
    """

    # ---------------------------------------------------------
    # PUBLIC API
    # ---------------------------------------------------------

    def generate_candidates(
        self,
        intents: List[Dict[str, Any]],
        context: Dict[str, Any],
    ) -> List[ExecutionPlan]:
        """
        Turn high-level intents into one or more execution plans.

        Each ExecutionPlan may contain:
          - steps (PlanStep list)
          - reason (human readable)
          - risk (PlanRisk)
          - confidence (0..1)
          - estimated_cost (rough units)
          - fallbacks (nested ExecutionPlan)
        """
        # 1) Normalize ambiguous calendar intents using raw message context
        raw_msg = (context.get("message") or "").lower()

        for intent in intents:
            if intent.get("type") == "calendar":
                params = intent.get("params") or {}
                action = (params.get("action") or "").lower()

                # Only override typical default/ambiguous actions
                if action in ("", "create", "add", "schedule"):
                    is_listy = any(
                        kw in raw_msg
                        for kw in [
                            "show my calendar",
                            "show me my calendar",
                            "show calendar",
                            "show me calendar",
                            "calendar for this week",
                            "my calendar for this week",
                            "calendar for today",
                            "calendar for tomorrow",
                            "show my upcoming events",
                            "upcoming events",
                            "show me my calendar for this week",
                        ]
                    )
                    has_create_verb = any(
                        kw in raw_msg
                        for kw in ["schedule", "create", "add", "book", "set up"]
                    )

                    if (("show" in raw_msg and "calendar" in raw_msg) or is_listy) and not has_create_verb:
                        params["action"] = "list"
                        intent["params"] = params

        # 2) Normal planning logic
        plans: List[ExecutionPlan] = []

        for intent in intents:
            t = intent.get("type")

            # --------------------
            # Calendar workflows
            # --------------------
            if t == "calendar":
                primary = self._calendar_primary(intent)
                fallback = self._calendar_fallback(intent)
                primary.fallbacks.append(fallback)
                plans.append(primary)

            # --------------------
            # Task workflows
            # --------------------
            elif t == "task":
                primary = self._task_primary(intent)
                fallback = self._task_fallback(intent)
                primary.fallbacks.append(fallback)
                plans.append(primary)

            # --------------------
            # Time / OS / web tooling
            # --------------------
            elif t in ("time", "os", "web"):
                plans.append(self._simple_tool(intent))

            # --------------------
            # Pure chat
            # --------------------
            elif t == "chat":
                plans.append(
                    ExecutionPlan(
                        steps=[],
                        reason="Pure conversational request; no tools needed.",
                        risk=PlanRisk.LOW,
                        confidence=0.95,
                        estimated_cost=0.05,
                    )
                )

            # --------------------
            # Unknown → conservative fallback
            # --------------------
            else:
                plans.append(
                    ExecutionPlan(
                        steps=[],
                        reason=f"Unknown intent type '{t}', falling back to chat.",
                        risk=PlanRisk.MEDIUM,
                        confidence=0.4,
                        estimated_cost=0.1,
                    )
                )

        return plans


    def pick_best(
        self,
        plans: List[ExecutionPlan],
        context: Dict[str, Any],
    ) -> ExecutionPlan:
        """
        Select the best plan given:
          - plan attributes (risk, confidence, cost)
          - global reasoning confidence
          - decision mode (force_tools / chat / clarify)
          - recent tool failures (from memory + verifier)
        """
        ranked = self.evaluate_plans(plans, context)
        best = ranked[0]

        # Optional: stash ranking in context for debug / traces
        context.setdefault("plan_debug", {})
        context["plan_debug"]["ranked_plans"] = [
            {
                "reason": p.reason,
                "risk": getattr(p.risk, "value", str(p.risk)),
                "confidence": p.confidence,
                "estimated_cost": p.estimated_cost,
                "steps": [s.tool for s in p.steps],
            }
            for p in ranked
        ]

        return best

    def evaluate_plans(
        self,
        plans: List[ExecutionPlan],
        context: Dict[str, Any],
    ) -> List[ExecutionPlan]:
        """
        Failure-aware scoring.

        Signals used:
          - plan.risk (LOW / MEDIUM / HIGH)
          - plan.confidence
          - plan.estimated_cost
          - decision.mode         (from Arbiter/Reasoning)
          - reasoning.confidence  (from ReasoningAgent)
          - recent tool failures  (from Memory / Verifier)
        """

        if not plans:
            return []

        decision = context.get("decision") or {}
        mode = (decision.get("mode") or "").lower()

        # Treat both "force_tools" and "tools" as "tools are required"
        force_tools = mode in ("force_tools", "tools")

        reasoning = context.get("reasoning") or {}
        try:
            global_conf = float(reasoning.get("confidence") or 0.5)
        except Exception:
            global_conf = 0.5

        # -------------------------
        # 1) Gather recent failures
        # -------------------------

        failed_tools: Set[str] = set()

        memory = context.get("memory") or {}
        episodes = memory.get("recent_episodes") or []

        for ep in episodes:
            meta = ep.get("meta") or {}
            verification = meta.get("verification") or {}
            for name in verification.get("failed_tools") or []:
                if isinstance(name, str):
                    failed_tools.add(name)

        # -------------------------
        # 2) Scoring function
        # -------------------------

        def score(p: ExecutionPlan):
            # Map risk levels to a small penalty
            risk_weight = {
                PlanRisk.LOW: 0,
                PlanRisk.MEDIUM: 1,
                PlanRisk.HIGH: 2,
            }.get(p.risk, 1)

            tool_names = {step.tool for step in p.steps}

            # Penalty if a plan uses tools that recently failed
            # (simple linear penalty for now)
            failed_overlap = tool_names.intersection(failed_tools)
            failure_penalty = len(failed_overlap) * 25  # tune as needed

            # If tools are required, heavily penalize pure-chat plans
            no_tools_penalty = 0
            if force_tools and len(p.steps) == 0:
                no_tools_penalty = 100

            # Combine local and global confidence
            effective_conf = (p.confidence or 0.0) * global_conf

            # Fewer steps is generally better for tie-breaking
            step_count = len(p.steps)

            # Lower tuple is better when sorted ascending
            return (
                no_tools_penalty + failure_penalty + risk_weight,  # main
                -effective_conf,                                   # prefer higher conf
                p.estimated_cost,                                  # cheaper is better
                step_count,                                        # fewer steps better
            )

        ranked = sorted(plans, key=score)
        return ranked

    # ---------------------------------------------------------
    # STRATEGIES: CALENDAR
    # ---------------------------------------------------------

    def _calendar_primary(self, intent: Dict[str, Any]) -> ExecutionPlan:
        """
        Main Google Calendar execution.
        """
        args = intent.get("params") or intent.get("args") or {}
        return ExecutionPlan(
            steps=[
                PlanStep(
                    tool="calendar_google",
                    args=args,
                    expected="Calendar event created / updated / listed",
                )
            ],
            reason="Primary Google Calendar plan",
            risk=PlanRisk.MEDIUM,
            confidence=0.85,
            estimated_cost=1.2,
        )

    def _calendar_fallback(self, intent: Dict[str, Any]) -> ExecutionPlan:
        """
        Fallback: no tools, just explain what *should* happen.
        """
        return ExecutionPlan(
            steps=[],
            reason="Fallback to conversational explanation if calendar fails.",
            risk=PlanRisk.LOW,
            confidence=0.4,
            estimated_cost=0.1,
        )

    # ---------------------------------------------------------
    # STRATEGIES: TASKS
    # ---------------------------------------------------------

    def _task_primary(self, intent: Dict[str, Any]) -> ExecutionPlan:
        args = intent.get("params") or intent.get("args") or {}
        return ExecutionPlan(
            steps=[
                PlanStep(
                    tool="tasks_google",
                    args=args,
                    expected="Task created / updated / completed",
                )
            ],
            reason="Primary Google Tasks execution.",
            risk=PlanRisk.MEDIUM,
            confidence=0.85,
            estimated_cost=1.1,
        )

    def _task_fallback(self, intent: Dict[str, Any]) -> ExecutionPlan:
        return ExecutionPlan(
            steps=[],
            reason="Fallback to conversational instructions for task handling.",
            risk=PlanRisk.LOW,
            confidence=0.4,
            estimated_cost=0.1,
        )

    # ---------------------------------------------------------
    # STRATEGIES: SIMPLE TOOL
    # ---------------------------------------------------------

    def _simple_tool(self, intent: Dict[str, Any]) -> ExecutionPlan:
        tool_name = intent.get("tool") or intent.get("type") or "unknown_tool"
        args = intent.get("params") or intent.get("args") or {}
        return ExecutionPlan(
            steps=[
                PlanStep(
                    tool=tool_name,
                    args=args,
                    expected="Tool executed successfully.",
                )
            ],
            reason=f"Single-step tool plan for '{tool_name}'.",
            risk=PlanRisk.LOW,
            confidence=0.9,
            estimated_cost=0.6,
        )
