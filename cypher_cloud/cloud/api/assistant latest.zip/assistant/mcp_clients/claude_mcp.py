from __future__ import annotations

from typing import Any, Dict, List, Optional
import os
import time

import httpx

from cloud.api.assistant.mcp.mcp_client_base import MCPClient
from cloud.api.assistant.mcp.models import MCPToolDescriptor, MCPCallResult
from cloud.api.assistant.mcp.errors import MCPConfigError, MCPToolError


class ClaudeMCP(MCPClient):
    """
    Generic MCP gateway client.

    Env:
      - CLAUDE_MCP_URL (base URL of your MCP gateway)
      - CLAUDE_MCP_TOKEN (optional auth token)
    """

    name = "claude"

    def __init__(self) -> None:
        super().__init__()
        self.api_key = os.getenv("CLAUDE_API_KEY")

        # AUTO-ENABLE: enabled only if API key exists
        self.enabled = bool(self.api_key)


    def _ensure_config(self) -> None:
        if not self._base_url:
            raise MCPConfigError("CLAUDE_MCP_URL is required for ClaudeMCP")

    async def health(self) -> Dict[str, Any]:
        try:
            self._ensure_config()
        except MCPConfigError as e:
            return {"status": "down", "error": str(e)}

        async with httpx.AsyncClient(base_url=self._base_url, timeout=5.0) as client:
            try:
                resp = await client.get("/health")
                return {
                    "status": "ok" if resp.status_code == 200 else "degraded",
                    "http_status": resp.status_code,
                }
            except Exception as e:
                return {"status": "degraded", "error": str(e)}

    async def list_tools(self) -> List[MCPToolDescriptor]:
        self._ensure_config()
        async with httpx.AsyncClient(base_url=self._base_url, timeout=10.0) as client:
            headers = {"Authorization": f"Bearer {self._token}"} if self._token else {}
            resp = await client.get("/tools", headers=headers)
            resp.raise_for_status()
            data = resp.json()
            tools: List[MCPToolDescriptor] = []
            for t in data.get("tools", []):
                tools.append(
                    MCPToolDescriptor(
                        name=t.get("name"),
                        description=t.get("description", ""),
                        input_schema=t.get("input_schema"),
                        output_schema=t.get("output_schema"),
                    )
                )
            return tools

    async def call(
        self,
        *,
        tool: str,
        payload: Dict[str, Any],
        ctx: Optional[Dict[str, Any]] = None,
    ) -> MCPCallResult:
        self._ensure_config()

        headers = {
            "Content-Type": "application/json",
        }
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"

        start = time.time()
        async with httpx.AsyncClient(base_url=self._base_url, timeout=60.0) as client:
            try:
                resp = await client.post(
                    "/call",
                    json={"tool": tool, "payload": payload, "ctx": ctx or {}},
                    headers=headers,
                )
                resp.raise_for_status()
                data = resp.json()

                duration_ms = (time.time() - start) * 1000.0
                success = bool(data.get("success", True))
                error = data.get("error")

                payload_out = {
                    "result": data.get("result"),
                    "_duration_ms": duration_ms,
                }

                return MCPCallResult(
                    tool=f"{self.name}.{tool}",
                    payload=payload_out,
                    success=success,
                    error=error,
                    raw=data,
                )

            except httpx.HTTPError as e:
                duration_ms = (time.time() - start) * 1000.0
                return MCPCallResult(
                    tool=f"{self.name}.{tool}",
                    payload={"_duration_ms": duration_ms},
                    success=False,
                    error=str(e),
                    raw=None,
                )
