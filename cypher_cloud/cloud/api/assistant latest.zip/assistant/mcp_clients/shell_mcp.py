from __future__ import annotations

import os
import time
import asyncio
from typing import Dict, Any, Optional, List

from cloud.api.assistant.mcp.mcp_client_base import MCPClient
from cloud.api.assistant.mcp.models import MCPToolDescriptor, MCPCallResult
from cloud.api.assistant.mcp.safety import validate_shell_command


class ShellMCP(MCPClient):
    name = "shell"

    def __init__(self) -> None:
        super().__init__()
        # Shell is always available
        self.enabled = True

    async def health(self) -> Dict[str, Any]:
        return {"status": "ok"}

    async def list_tools(self) -> List[MCPToolDescriptor]:
        return [
            MCPToolDescriptor(
                name="exec",
                description="Execute a shell command (Windows-safe)",
            )
        ]

    async def call(
        self,
        *,
        tool: str,
        payload: Dict[str, Any],
        ctx: Optional[Dict[str, Any]] = None,
    ) -> MCPCallResult:
        start = time.time()

        if tool != "exec":
            return MCPCallResult(
                tool="shell.exec",
                payload={},
                success=False,
                error=f"Unknown shell tool: {tool}",
            )

        cmd = payload.get("cmd")
        validate_shell_command(cmd)

        # Windows-safe execution
        if os.name == "nt":
            cmd = f"cmd /c {cmd}"

        proc = await asyncio.create_subprocess_shell(
            cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        out, err = await proc.communicate()

        duration_ms = (time.time() - start) * 1000

        return MCPCallResult(
            tool="shell.exec",
            payload={
                "stdout": out.decode(errors="ignore"),
                "stderr": err.decode(errors="ignore"),
                "_duration_ms": duration_ms,
            },
            success=proc.returncode == 0,
            error=None if proc.returncode == 0 else err.decode(errors="ignore"),
        )
