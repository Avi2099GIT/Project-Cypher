# # cloud/api/assistant/agents_dir/executor_agent.py
# from __future__ import annotations

# from typing import Any, Dict, List
# import logging

# from cloud.api.assistant.tools_registry import tool_registry
# from cloud.api.assistant.tools_base import ToolContext
# from cloud.api.assistant.orchestrator.tracer import tracer
# logger = logging.getLogger(__name__)


# class ExecutorAgent:
 
#     async def run(
#         self,
#         steps: List[Dict[str, Any]],
#         ctx: Dict[str, Any],
#     ) -> List[Dict[str, Any]]:
        
#         device = ctx.get("device") or {"device_id": "local-dev"}
#         history = ctx.get("history") or []
#         message = ctx.get("message") or ""

#         tool_ctx = ToolContext(
#             device=device,
#             history=history,
#             message=message,
#         )

#         results: List[Dict[str, Any]] = []

#         for step in steps:
#             name = step.get("tool")
#             args = step.get("args") or {}

#             if not name:
#                 continue

#             try:
#                 result = await tool_registry.call(name=name, args=args, ctx=tool_ctx)

#                 # Convert status:error into exception
#                 if isinstance(result, dict) and result.get("status") == "error":
#                     raise RuntimeError(result.get("message", "Tool execution failed"))

#                 results.append(
#                     {
#                         "tool": name,
#                         "args": args,
#                         "result": result,
#                     }
#                 )

#             except Exception as e:
#                 logger.exception("ExecutorAgent: error calling tool %s: %s", name, e)
#                 results.append(
#                     {
#                         "tool": name,
#                         "args": args,
#                         "error": str(e),
#                     }
#                 )
#                 # 🔴 propagate upwards so the graph marks this node as FAILED
#                 raise

#         return results



# cloud/api/assistant/agents_dir/executor_agent.py
from __future__ import annotations

from typing import Any, Dict, List, Optional
import logging
import time

from cloud.api.assistant.tools_registry import tool_registry
from cloud.api.assistant.tools_base import ToolContext
from cloud.api.assistant.orchestrator.tracer import tracer
from cloud.api.assistant.orchestrator.node import NodeStatus

from cloud.api.assistant.mcp.registry import mcp_registry
from cloud.api.assistant.mcp.errors import (
    MCPError,
    MCPConfigError,
    MCPConnectionError,
    MCPNotAvailableError,
)
from cloud.api.assistant.mcp.models import MCPCallResult

logger = logging.getLogger(__name__)


class ExecutorAgent:
    """
    Executes planned tool steps.

    Supports:
      - built-in tools via ToolRegistry
      - MCP tools via mcp:<client>.<tool_name>
    """

    async def _call_mcp_tool(
    self,
    *,
    full_name: str,
    args: Dict[str, Any],
    ctx: Dict[str, Any],
) -> Dict[str, Any]:

        try:
            _, rest = full_name.split(":", 1)
            client_name, tool_name = rest.split(".", 1)
        except ValueError:
            raise ValueError(
                f"Invalid MCP tool name '{full_name}'. "
                "Expected format: mcp:<client>.<tool_name>"
            )

        trace_id: Optional[str] = ctx.get("trace_id")
        start = time.time()

        try:
            mcp_result: MCPCallResult = await mcp_registry.call(
                client_name=client_name,
                tool=tool_name,
                payload=args,
                ctx=ctx,
            )

        except (MCPConfigError, MCPNotAvailableError, MCPConnectionError):
            # ⬅️ Environment-level MCP failure → SOFT
            raise

        duration_ms = mcp_result.payload.get("_duration_ms")
        if duration_ms is None:
            duration_ms = (time.time() - start) * 1000.0

        if trace_id:
            tracer.record(
                trace_id=trace_id,
                node=f"mcp:{client_name}.{tool_name}",
                status=NodeStatus.SUCCESS if mcp_result.success else NodeStatus.FAILED,
                message="MCP call" if mcp_result.success else (mcp_result.error or ""),
                extra={
                    "duration_ms": duration_ms,
                    "client": client_name,
                    "tool": tool_name,
                },
            )

        # ⬇️ TOOL-LEVEL FAILURE → RETURN, DO NOT RAISE
        return {
            "client": client_name,
            "tool": tool_name,
            "success": mcp_result.success,
            "result": mcp_result.payload,
            #"payload": mcp_result.payload,
            "error": mcp_result.error,
            "duration_ms": duration_ms,
        }


    async def run(
        self,
        steps: List[Dict[str, Any]],
        ctx: Dict[str, Any],
    ) -> List[Dict[str, Any]]:

        device = ctx.get("device") or {"device_id": "local-dev"}
        history = ctx.get("history") or []
        message = ctx.get("message") or ""

        tool_ctx = ToolContext(
            device=device,
            history=history,
            message=message,
        )

        results: List[Dict[str, Any]] = []

        for step in steps:
            # ✅ Support PlanStep objects
            if hasattr(step, "tool"):
                name = step.tool
                args = step.args or {}
            else:
                name = step.get("tool")
                args = step.get("args") or {}

            if not name:
                continue

            
            # -------------------------
            # MCP path
            # -------------------------
            if isinstance(name, str) and name.startswith("mcp:"):
                try:
                    mcp_out = await self._call_mcp_tool(
                        full_name=name,
                        args=args,
                        ctx=ctx,
                    )

                    if mcp_out["success"]:
                        results.append(
                            {
                                "tool": name,
                                "args": args,
                                "result": mcp_out["result"],
                                "type": "mcp",
                            }
                        )
                    else:
                        # Tool ran but failed → verifier handles this
                        results.append(
                            {
                                "tool": name,
                                "args": args,
                                "error": mcp_out.get("error"),
                                "type": "mcp",
                            }
                        )

                    continue

                except (MCPConfigError, MCPNotAvailableError, MCPConnectionError) as e:
                    # ⬅️ MCP unavailable → soft failure
                    logger.warning("MCP unavailable for %s: %s", name, e)
                    results.append(
                        {
                            "tool": name,
                            "args": args,
                            "error": str(e),
                            "type": "mcp",
                            "mcp_fallback": True,
                        }
                    )
                    continue

                except MCPError as e:
                    # ⬅️ True MCP internal error → hard failure
                    logger.exception("Hard MCP error calling %s", name)
                    raise


        return results
